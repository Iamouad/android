package azouay.mouad.app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.List;

import azouay.mouad.app.pojos.Photo;
import azouay.mouad.app.services.ApiService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    ApiService service;
    List<Photo> photos;
    RecyclerView rvPhotos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rvPhotos = findViewById(R.id.recyclerPhoto);
        rvPhotos.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        service = new Retrofit.Builder()
                .baseUrl(ApiService.ENDPOINT)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiService.class);

        service.listPhotos().enqueue(new Callback<List<Photo>>() {
            @Override
            public void onResponse(Call<List<Photo>> call, Response<List<Photo>> response) {
                photos = response.body();
                System.out.println("photos..........." + photos.size());
                PhotoAdapter adapter = new PhotoAdapter(photos);
                rvPhotos.setAdapter(adapter);
                MainActivity.this.setTitle("Tst");
            }

            @Override
            public void onFailure(Call<List<Photo>> call, Throwable t) {
                System.out.println("errrrrrrrrrr"+t.getMessage());
            }
        });
    }

    
}